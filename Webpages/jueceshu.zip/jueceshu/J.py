import jichu
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import seaborn as sns
import shap

embedding_columns = ['Material']
bool_column = ['Copper containing']

# 定义特征列和目标列
X = jichu.df[embedding_columns + bool_column + ['Voltage', 'Electrolyte flow rate', 'MEA configuration',
                                          'Electrolyte', 'Membrane','Anode', 'CO₂ flow rate',
                                                               'MEA area', 'Membrane area', 'Anode area',
                                                               'Anode catalyst loading', 'Cathode area',
                                                               'Cathode catalyst loading', 'Temperature', 'Electrolyte concentration']]
y = jichu.df['first_product']

# 对目标列进行编码
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
# 获取编码后的数字和原始元素的对应关系
encoded_to_original = dict(zip(label_encoder.transform(label_encoder.classes_), label_encoder.classes_))

# 打印对应关系
for encoded_value, original_value in encoded_to_original.items():
    print(f"编码值: {encoded_value} 对应原始值: {original_value}")
# 划分训练集和测试集
X_trainval, X_test, y_trainval, y_test = train_test_split(X, y_encoded, train_size=0.75, test_size=0.25, random_state=42)
from sklearn.tree import DecisionTreeClassifier, export_graphviz
import graphviz

# 构建决策树分类器
dt_classifier = DecisionTreeClassifier(random_state=42)

# 在训练集上训练决策树分类器
dt_classifier.fit(X_trainval, y_trainval)

# 获取特征重要性
feature_importances = dt_classifier.feature_importances_

# 将特征重要性与特征名称对应起来
feature_names = X.columns
feature_importance_dict = dict(zip(feature_names, feature_importances))

# 按照重要性对特征进行排序
sorted_feature_importances = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 打印决策树特征重要度排序
print("Decision Tree Feature Importance Ranking:")
for feature, importance in sorted_feature_importances:
    print(f"{feature}: {importance}")

# 进行决策树剪枝操作
# 这里简单示例设置一个最大深度来实现剪枝效果，实际应用中可根据具体情况调整策略
dt_classifier_pruned = DecisionTreeClassifier(max_depth=3, random_state=42)
dt_classifier_pruned.fit(X_trainval, y_trainval)

# 可视化决策树（需要安装graphviz软件并将其添加到系统路径中，否则无法正确显示图形）
dot_data = export_graphviz(dt_classifier_pruned, out_file=None,
                           filled=True, rounded=True,
                           special_characters=True, feature_names=X.columns, class_names=label_encoder.classes_)
graph = graphviz.Source(dot_data)
graph.render("first_product_pruned_decision_tree")  # 这会生成一个名为pruned_decision_tree的文件（可以是pdf、png等格式，取决于系统设置）
# 根据特征重要性分析提出改进策略示例（这里只是简单示例，可根据实际情况深入分析）
for feature, importance in sorted_feature_importances:
    if importance > 0.1:  # 假设重要性大于0.1的特征作为关键影响因素
        print(f"To improve the performance of the membrane electrode device, pay more attention to optimizing {feature}.")