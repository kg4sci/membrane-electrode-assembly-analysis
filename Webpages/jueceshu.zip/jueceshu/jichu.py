#导入表格数据
import pandas as pd
df=pd.read_excel('C:\\Users\\hp\\Desktop\\keshe\\去单位填平均数后.xlsx')
from sklearn.preprocessing import LabelEncoder
# 进行标签编码
le = LabelEncoder()
df['First product'] = le.fit_transform(df['first_product'])
# 列进行标签编码
df['MEA configuration'] = le.fit_transform(df['MEA_configuration'])
df['Electrolyte'] = le.fit_transform(df['electrolyte_2'])
df['Membrane'] = le.fit_transform(df['membrane'])
df['Anode'] = le.fit_transform(df['anode'])
import os
import numpy as np
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
# 读取要转换的material列数据集
datas = df['material'].unique()
# 加载模型
embed_model = HuggingFaceEmbedding(model_name="sentence-transformers/all-MiniLM-L6-v2")
# 获取文本的嵌入向量并添加到新列
embeddings = [embed_model.get_text_embedding(data) for data in datas]
df['material_embeddings'] = [embeddings[list(datas).index(material)] for material in df['material']]
material_embeddings_means = df['material_embeddings'].apply(lambda x: np.mean(x))
df['Material'] = material_embeddings_means
df['first_product'] = df['first_product'].replace('C2H4', 'C₂H₄')
df['first_product'] = df['first_product'].replace('C2H5OH', 'C₂H₅OH')
df['first_product'] = df['first_product'].replace('CH3COOH', 'CH₃COOH')
df['first_product'] = df['first_product'].replace('CH3OH', 'CH₃OH')
df['first_product'] = df['first_product'].replace('CH4', 'CH₄')
df['first_product'] = df['first_product'].replace('H2C2O4', 'H₂C₂O₄')


df.rename(columns={'voltage': 'Voltage'}, inplace=True)
df.rename(columns={'electrolyte_flow_anolyte_rate': 'Electrolyte flow rate'}, inplace=True)
df.rename(columns={'CO2_flow_rate': 'CO₂ flow rate'}, inplace=True)
df.rename(columns={'MEA_area': 'MEA area'}, inplace=True)
df.rename(columns={'membrane_area': 'Membrane area'}, inplace=True)
df.rename(columns={'anode_area': 'Anode area'}, inplace=True)
df.rename(columns={'anode_catalyst_loading': 'Anode catalyst loading'}, inplace=True)
df.rename(columns={'cathode_area': 'Cathode area'}, inplace=True)
df.rename(columns={'cathode_catalyst_loading': 'Cathode catalyst loading'}, inplace=True)
df.rename(columns={'temperature': 'Temperature'}, inplace=True)
df.rename(columns={'electrolyte_1': 'Electrolyte concentration'}, inplace=True)
df.rename(columns={'copper_containing': 'Copper containing'}, inplace=True)