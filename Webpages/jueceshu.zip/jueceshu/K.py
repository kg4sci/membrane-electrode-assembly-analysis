import numpy as np
import pandas as pd
from skimage.metrics import mean_squared_error

import jichu
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score, r2_score
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import seaborn as sns
import shap
jichu.df.rename(columns={'first_product_faraday_efficiency': 'First product faraday efficiency'}, inplace=True)
jichu.df['First product faraday efficiency'] = jichu.df['First product faraday efficiency'] / 100
embedding_columns = ['Material']
bool_column = ['Copper containing']
# 定义特征列和目标列
X = jichu.df[embedding_columns + bool_column + ['Voltage', 'Electrolyte flow rate', 'MEA configuration',
                                          'Electrolyte', 'Membrane','Anode', 'CO₂ flow rate',
                                                               'MEA area', 'Membrane area', 'Anode area',
                                                               'Anode catalyst loading', 'Cathode area',
                                                               'Cathode catalyst loading', 'Temperature', 'Electrolyte concentration','First product']]
y = jichu.df['First product faraday efficiency']
# 划分训练集和测试集
X_trainval, X_test, y_trainval, y_test = train_test_split(X, y, train_size=0.75, test_size=0.25, random_state=42)
from sklearn.tree import DecisionTreeRegressor, export_graphviz
import graphviz
# 构建决策树回归器
dt_regressor = DecisionTreeRegressor(random_state=42)

# 在训练集上训练决策树回归器
dt_regressor.fit(X_trainval, y_trainval)

# 获取特征重要性
feature_importances = dt_regressor.feature_importances_

# 将特征重要性与特征名称对应起来
feature_names = X.columns
feature_importance_dict = dict(zip(feature_names, feature_importances))

# 按照重要性对特征进行排序
sorted_feature_importances = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 打印决策树特征重要度排序
print("Decision Tree Feature Importance Ranking:")
for feature, importance in sorted_feature_importances:
    print(f"{feature}: {importance}")

# 进行决策树剪枝操作
# 这里简单示例设置一个最大深度来实现剪枝效果，实际应用中可根据具体情况调整策略
dt_regressor_pruned = DecisionTreeRegressor(max_depth=3, random_state=42)
dt_regressor_pruned.fit(X_trainval, y_trainval)

# 可视化决策树（需要安装graphviz软件并将其添加到系统路径中，否则无法正确显示图形）
dot_data = export_graphviz(dt_regressor_pruned, out_file=None,
                           filled=True, rounded=True,
                           special_characters=True, feature_names=X.columns, class_names=None)
graph = graphviz.Source(dot_data)
graph.render("First product faraday efficiency_decision_tree")  # 这会生成一个名为pruned_decision_tree的文件（可以是pdf、png等格式，取决于系统设置）

# 根据特征重要性分析提出改进策略示例（这里只是简单示例，可根据实际情况深入分析）
for feature, importance in sorted_feature_importances:
    if importance > 0.1:  # 假设重要性大于0.1的特征作为关键影响因素
        if feature == 'Voltage':
            print(f"To improve the performance of the membrane electrode device, consider adjusting the {feature} within a more optimal range.")
        elif feature == 'MEA configuration':
            print(f"To improve the performance of the membrane electrode device, explore different {feature} options to find a more suitable combination.")
        elif feature == 'Anode catalyst loading':
            print(f"To improve the performance of the membrane electrode device, optimize the {feature} to achieve better performance.")
        # 可根据其他重要特征继续添加针对性的改进策略